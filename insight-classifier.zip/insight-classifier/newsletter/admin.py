from django.contrib import admin

# Register your models here.
from .forms import SignUpForm, EmailForm
from .models import SignUp, Email

class SignUpAdmin(admin.ModelAdmin):
	list_display = ["__unicode__", "timestamp", "updated"]
	form = SignUpForm
	# class Meta:
	# 	model = SignUp


class EmailAdmin(admin.ModelAdmin):
	list_display = ["__unicode__", "timestamp", "is_spam", "email_id", "from_address", "to_address", "subject", "body"]
	form = EmailForm
	# class Meta:
	# 	model = SignUp

admin.site.register(SignUp, SignUpAdmin)
admin.site.register(Email, EmailAdmin)
