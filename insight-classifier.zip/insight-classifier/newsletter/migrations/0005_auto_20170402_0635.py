# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('newsletter', '0004_auto_20170401_2331'),
    ]

    operations = [
        migrations.AlterField(
            model_name='email',
            name='body',
            field=models.TextField(max_length=20000, null=True, blank=True),
        ),
    ]
