# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('newsletter', '0007_auto_20170402_0734'),
    ]

    operations = [
        migrations.AlterField(
            model_name='email',
            name='body',
            field=models.CharField(max_length=20000, null=True, blank=True),
        ),
    ]
