from __future__ import unicode_literals

from django.db import models

# Create your models here.
# Login Model
class SignUp(models.Model):
	email = models.EmailField()
	full_name = models.CharField(max_length = 120, blank = True, null = True)
	timestamp = models.DateTimeField(auto_now_add = True, auto_now = False)
	updated = models.DateTimeField(auto_now_add = False, auto_now = True)

	# this is what will be returned as instance of the class
	# Python 3 __str__
	def __unicode__(self):
		return self.email

class Email(models.Model):
	email_id = models.AutoField(primary_key=True)
	from_address = models.EmailField()
	to_address = models.EmailField()
	subject = models.CharField(max_length = 500, blank = True, null = True)
	body = models.CharField(max_length = 20000, blank = True, null = True)
	timestamp = models.DateTimeField(auto_now_add = True, auto_now = False)
	updated = models.DateTimeField(auto_now_add = False, auto_now = True)
	is_spam = models.CharField(max_length='2', default='0')

	# this is what will be returned as instance of the class
	# Python 3 __str__
	def __unicode__(self):
		return self.subject
