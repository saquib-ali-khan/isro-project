import re
from string import digits
from sklearn.feature_extraction.text import CountVectorizer
from keras.models import model_from_json
import pickle as pkl
import numpy as np
import string

def translate_non_alphanumerics(to_translate, translate_to=u'_'):
    not_letters_or_digits = u'!"#%\'()*+,-./:;<=>?@[\]^_`{|}~'
    translate_table = dict((ord(char), translate_to) for char in not_letters_or_digits)
    return to_translate.translate(translate_table)

def perform_preprocessing(text):
    ## Remove punctuation,whitespaces,digits
    text = re.sub(r'\b\w{1,3}\b', ' ',text)
    text = re.sub(r'[^\w\s]',' ',text)
    text = translate_non_alphanumerics(text, u'_')
    return text


def feature_vector(X,vocabulary,vocab_size=1000):
	cv = CountVectorizer(max_df=0.95, min_df=2,max_features=vocab_size,stop_words='english',vocabulary=vocabulary)
	return cv.transform(X)

def apply_model(model,X_test,y_test=None):
        if y_test == None:
            return model.predict_classes(X_test.todense(),verbose=0)
        else:
            return np.mean(y_test == model.predict_classes(X_test.todense(),verbose=0))
