from django.conf import settings
from django.core.mail import send_mail
from django.shortcuts import render
from .forms import SignUpForm, ContactForm, EmailForm
from .models import Email
from django.http import HttpResponseRedirect
import keras.backend as K
from keras.models import model_from_json
from utils import *
import pickle as pkl

# Create your views here.

def home(request):

	# # THIS IS HOW YOU CHECK THE USER/ADMIN LOGIN
	# title = "Hello"
	# if request.user.is_authenticated():
	# 	title = 'Hello %s' %(request.user)

	# if request.method == 'POST':
	# 	print request.POST

	form = SignUpForm(request.POST or None)
	context = {
		"form":form
	}

	if form.is_valid():
		instance = form.save(commit = False)
		## Do sth
		instance.save()

	return render(request, "home.html", context)


def contact(request):
	form = ContactForm(request.POST or None)
	if form.is_valid():
		for key, value in form.cleaned_data.iteritems():
			print key, value
		form_full_name = form.cleaned_data.get("full_name")
		form_email = form.cleaned_data.get("email")
		form_message = form.cleaned_data.get("message")

		from_email = settings.EMAIL_HOST_USER
		to_email = [from_email, "zafarullahmahmood777@gmail.com"]

		contact_message = '%s\n%s\n%s' %(
			form_full_name,
			form_email,
			form_message)

		send_mail('Feedback', contact_message, from_email, to_email, fail_silently=False)

	context = {
		"form": form,
	}
	return render(request, "contact.html", context)


def compose(request):

	form = EmailForm(request.POST or None)
	context = {
		"form":form
	}

	if form.is_valid():
		instance = form.save(commit = False)
		data = instance.body
		X = perform_preprocessing(data)
		K.clear_session()
		with open('vocabulary.pkl', 'rb') as fp:
			vocabulary = pkl.load(fp)
		X = feature_vector([X], vocabulary=vocabulary)

		with open('modeltf.json', 'rb') as fp:
			model = model_from_json(fp.read())

		model.load_weights('modeltf.h5', 'rb')

		ypred = apply_model(model, X)

		if ypred[0][0] == 1:
			
			instance.is_spam = 1


		if not instance.from_address:
			instance.from_address = request.user.email

		instance.save()
		return render(request, "email_success.html", context)

	return render(request, "compose.html", context)


def spam(request):

	mails = Email.objects.filter(to_address=request.user.email, is_spam='1').order_by('-timestamp')

	context = {
		"mails": mails
	}

	return render(request, "spam.html", context)

def inbox(request):

	mails = Email.objects.filter(to_address=request.user.email, is_spam='0').order_by('-timestamp')

	context = {
		"mails": mails
	}
	return render(request, "inbox.html", context)


def sent(request):

	mails = Email.objects.filter(from_address=request.user.email).order_by('-timestamp')

	context = {
		"mails": mails
	}
	return render(request, "sent.html", context)

def mark_spam(request, email_id):
	try:

		instance = Email.objects.get(email_id=email_id)
		instance.is_spam = "1"
		instance.save()
		return HttpResponseRedirect("/inbox/")
	except:
		print 10000000
		return render(request, "email_success.html")


def mark_ham(request, email_id):
	try:

		instance = Email.objects.get(email_id=email_id)
		instance.is_spam = "0"
		instance.save()
		return HttpResponseRedirect("/spam/")
	except:
		print 10000000
		return render(request, "email_success.html")
